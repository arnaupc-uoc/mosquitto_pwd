"""
mosquitto_pwd

Generate and verify mosquitto password digest.
"""

__version__ = "0.1.0"
__author__ = 'Arnau Pujol Cabarocas'
__credits__ = 'Bianna Business'
